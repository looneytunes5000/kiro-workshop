# Paraphrase Practice

A web-based paraphrasing practice tool designed to help students and writers improve their paraphrasing skills through interactive exercises with instant feedback.

## Features

- **Three Difficulty Levels**: Beginner, Intermediate, and Advanced passages
- **Instant Feedback**: Real-time analysis of paraphrase quality with scoring
- **Smart Evaluation**: Word overlap detection, length analysis, and structure assessment
- **Example Paraphrases**: View model answers for each passage
- **Custom Passages**: Teacher Mode allows adding custom exercises
- **Progress Tracking**: Automatic save/resume functionality using localStorage
- **Responsive Design**: Works on desktop and mobile devices
- **Accessibility**: Keyboard shortcuts, ARIA labels, and reduced motion support

## Quick Start

### Prerequisites

- Node.js (v14 or higher) - for running the local development server
- Any modern web browser

### Installation

1. Clone or download this repository:
   ```bash
   git clone <repository-url>
   cd Prarphraser
   ```

2. Start the local development server:
   ```bash
   npm start
   ```

3. Open your browser and navigate to:
   ```
   http://localhost:8080
   ```

That's it! The app will be running locally.

## Usage

### Basic Workflow

1. **Select Difficulty**: Choose from All Levels, Beginner, Intermediate, or Advanced
2. **Read the Passage**: Carefully read the original text
3. **Write Your Paraphrase**: Type your version in the text area
4. **Check Answer**: Submit to receive instant feedback and scoring
5. **Continue**: Move to the next exercise or view examples

### Keyboard Shortcuts

- `Ctrl + Enter`: Submit your paraphrase
- `Escape`: Close modals

### Teacher Mode

Click the "Teacher Mode" button in the header to:
- Add custom passages with difficulty levels and topics
- Provide tips and example paraphrases for each passage
- Manage your custom passage library

## Project Structure

```
Prarphraser/
├── index.html          # Main application (HTML, CSS, and JavaScript)
├── package.json        # Project metadata and scripts
├── serve.js            # Development server script
├── .gitignore          # Git ignore rules
├── LICENSE             # MIT License
└── README.md           # This file
```

## How It Works

The app evaluates paraphrases using several metrics:

1. **Word Overlap**: Measures how many significant words match the original
2. **Length Ratio**: Compares word count to ensure appropriate paraphrase length
3. **Vocabulary Variety**: Identifies new words introduced in your paraphrase
4. **Sentence Structure**: Detects changes in sentence count and structure

Scores are calculated based on how different your paraphrase is from the original while maintaining similar length and meaning.

## Development

### Running the Server

```bash
npm start
# or
npm run dev
```

The server uses Node.js built-in `http` module - no additional dependencies required for production use.

### Customizing Passages

All passages are stored in the `defaultPassages` array within `index.html`. Each passage includes:

- `id`: Unique identifier
- `text`: The original passage
- `difficulty`: "beginner", "intermediate", or "advanced"
- `topic`: Subject category
- `tips`: Array of paraphrasing tips
- `example`: Model paraphrase

## Contributing

Contributions are welcome! Here's how you can help:

1. **Add More Passages**: Contribute passages for different difficulty levels and topics
2. **Improve Evaluation**: Enhance the paraphrase scoring algorithm
3. **Add Features**: Suggest new features via issues
4. **Fix Bugs**: Report or fix any issues you encounter

### How to Contribute

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Built with vanilla HTML, CSS, and JavaScript
- Uses Google Fonts (Lora and DM Sans) for typography
